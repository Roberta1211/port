package com.example.login;

public class Usuario {
    String login;
    String senha;

    public Usuario(String login, String senha) {
        this.login = login;
        this.senha = senha;
    }
}
